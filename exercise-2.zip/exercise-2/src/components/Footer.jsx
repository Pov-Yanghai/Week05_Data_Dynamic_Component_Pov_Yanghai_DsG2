import React from "react";

function Footer() {
  return (
    <footer className="block">
      <p>You can find the React doc at <a href="https://react.dev/" target="_blank" rel="noopener noreferrer">React.dev</a></p>
    </footer>
  );
}

export default Footer;
